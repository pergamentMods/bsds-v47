# This is a fork from original BSDS by [Crazor](https://github.com/CrazorTheCat)  with a lot less features, it is meant for developement, do not use for production and hosting for others.

Discord link : https://discord.gg/mt4dUxXryh

iOS : https://mega.nz/file/x5MnUarQ#uyOo1KFtB-GWmtTV9c8CEHE2swtG8EVddJnxXdBMLU8

Second link (fix crash on non-jb device but can't play alongside Brawl Stars, need to delete bs to play) : https://mega.nz/file/UgM02BjB#ffctMG9YrRpXDr-ZdekR-TE3Gs7Gf6IsDsuQwSo1KFU 

## Requirements: ##
1. a brain...

## How to play BSDS: ##
1: download server and client

2: extract client and go to Frameworks folder and open BSDS.config

2.1: change the ipv4 address of your device you execute the server from

2.2: save and compile back to ipa format.

3: install the client using your favorite app installer.

4: open terminal on your computer and go to BSDS directory.

5: now you need to install crypto module.

5.1: type cd Classes/Crypto

5.2: now type python setup.py install

6: go back to BSDS root directory.

7: type python Core.py

8: now open the game and play.

![image](https://user-images.githubusercontent.com/72312877/213475759-20669970-c333-4b10-b7e9-073995d38472.png)

## credits ##
[S.B#0056](https://github.com/HaccerCat) for his help with crypto and client

[Vitalik](https://github.com/VitalikObject) for his crypto from [OldBrawl](https://github.com/VitalikObject/OldBrawl)
